import { useState, useEffect } from 'react';
import Header from './components/Header';
import CryptoTable from './components/CryptoTable';
import PortfolioAllocation from './components/PortfolioAllocation';
import { cryptoCoins as initialCryptoCoins, portfolioHoldings as initialPortfolioHoldings, CryptoCoin, PortfolioHolding } from './data/cryptoData';

export default function App() {
  const [coins, setCoins] = useState<CryptoCoin[]>(initialCryptoCoins);
  const [holdings, setHoldings] = useState<PortfolioHolding[]>(initialPortfolioHoldings);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  const updatePrices = () => {
    // Simulate price updates with random fluctuations
    const updatedCoins = coins.map(coin => {
      const randomChange = (Math.random() - 0.5) * 2; // -1% to +1%
      const newPrice = coin.currentPrice * (1 + randomChange / 100);
      const newChange24h = coin.change24h + randomChange;
      
      // Generate new sparkline data
      const lastSparklineValue = coin.sparklineData[coin.sparklineData.length - 1];
      const newSparklineValue = lastSparklineValue * (1 + (Math.random() - 0.5) * 0.02); // -1% to +1%
      const newSparklineData = [...coin.sparklineData.slice(1), newSparklineValue];
      
      return {
        ...coin,
        currentPrice: parseFloat(newPrice.toFixed(2)),
        change24h: parseFloat(newChange24h.toFixed(2)),
        sparklineData: newSparklineData,
        volume24h: coin.volume24h * (1 + Math.random() * 0.1),
        marketCap: coin.marketCap * (1 + randomChange / 100)
      };
    });

    // Update holdings values based on new prices
    const updatedHoldings = holdings.map(holding => {
      const coin = updatedCoins.find(c => c.id === holding.coinId);
      if (coin) {
        const newValue = holding.amount * coin.currentPrice;
        return {
          ...holding,
          value: parseFloat(newValue.toFixed(2))
        };
      }
      return holding;
    });

    setCoins(updatedCoins);
    setHoldings(updatedHoldings);
    setLastUpdated(new Date());
  };

  const handleRefresh = () => {
    updatePrices();
  };

  const currentTotalPortfolioValue = holdings.reduce((sum, holding) => sum + holding.value, 0);

  // Auto-refresh every 30 seconds for demo purposes
  useEffect(() => {
    const interval = setInterval(() => {
      updatePrices();
    }, 30000);

    return () => clearInterval(interval);
  }, [coins, holdings]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-2">
          <div className="text-sm text-gray-500">
            Last updated: {formatTime(lastUpdated)}
          </div>
          <div className="text-sm text-gray-500">
            Auto-refresh every 30s
          </div>
        </div>
        
        <Header onRefresh={handleRefresh} />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <div className="lg:col-span-2">
            <CryptoTable coins={coins} />
          </div>
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Quick Stats</h2>
                <button
                  onClick={handleRefresh}
                  className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                >
                  Update Now
                </button>
              </div>
              <div className="space-y-4">
                {coins.map((coin) => (
                  <div key={coin.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold"
                        style={{ backgroundColor: coin.color }}
                      >
                        {coin.icon}
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">{coin.symbol}</div>
                        <div className="text-sm text-gray-500">{coin.name}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-gray-900">
                        ${coin.currentPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                      <div className={`text-sm font-medium ${coin.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {coin.change24h >= 0 ? '+' : ''}{coin.change24h.toFixed(2)}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <PortfolioAllocation holdings={holdings} />
        </div>

        <footer className="mt-8 text-center text-gray-500 text-sm">
          <p>Data is simulated for demonstration purposes. Prices update automatically every 30 seconds.</p>
          <p className="mt-2">Crypto Tracker Dashboard • Built with React, Vite, Tailwind CSS & Recharts</p>
        </footer>
      </div>
    </div>
  );
}
