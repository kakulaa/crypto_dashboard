import { LineChart, Line, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { CryptoCoin, formatCurrency, formatLargeNumber } from '../data/cryptoData';

interface CryptoTableProps {
  coins: CryptoCoin[];
}

export default function CryptoTable({ coins }: CryptoTableProps) {
  return (
    <div className="bg-white rounded-2xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Cryptocurrency Prices</h2>
        <div className="text-sm text-gray-500">
          Real-time data • Updated just now
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-4 px-2 text-sm font-semibold text-gray-600">Asset</th>
              <th className="text-left py-4 px-2 text-sm font-semibold text-gray-600">Price</th>
              <th className="text-left py-4 px-2 text-sm font-semibold text-gray-600">24h Change</th>
              <th className="text-left py-4 px-2 text-sm font-semibold text-gray-600">Market Cap</th>
              <th className="text-left py-4 px-2 text-sm font-semibold text-gray-600">Volume (24h)</th>
              <th className="text-left py-4 px-2 text-sm font-semibold text-gray-600">Sparkline</th>
            </tr>
          </thead>
          <tbody>
            {coins.map((coin) => (
              <tr key={coin.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors animate-fade-in">
                <td className="py-4 px-2">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-lg"
                      style={{ backgroundColor: coin.color }}
                    >
                      {coin.icon}
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">{coin.name}</div>
                      <div className="text-sm text-gray-500">{coin.symbol}</div>
                    </div>
                  </div>
                </td>
                <td className="py-4 px-2">
                  <div className="font-semibold text-gray-900">{formatCurrency(coin.currentPrice)}</div>
                </td>
                <td className="py-4 px-2">
                  <div className={`flex items-center gap-1 ${coin.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {coin.change24h >= 0 ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    <span className="font-semibold">{coin.change24h >= 0 ? '+' : ''}{coin.change24h.toFixed(2)}%</span>
                  </div>
                </td>
                <td className="py-4 px-2">
                  <div className="font-medium text-gray-900">{formatLargeNumber(coin.marketCap)}</div>
                </td>
                <td className="py-4 px-2">
                  <div className="font-medium text-gray-900">{formatLargeNumber(coin.volume24h)}</div>
                </td>
                <td className="py-4 px-2">
                  <div className="w-32 h-10">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={coin.sparklineData.map((value, index) => ({ value, index }))}>
                        <Line
                          type="monotone"
                          dataKey="value"
                          stroke={coin.change24h >= 0 ? '#10B981' : '#EF4444'}
                          strokeWidth={2}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}