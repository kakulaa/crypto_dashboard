import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { PortfolioHolding, formatCurrency, totalPortfolioValue, getCoinById } from '../data/cryptoData';

interface PortfolioAllocationProps {
  holdings: PortfolioHolding[];
}

export default function PortfolioAllocation({ holdings }: PortfolioAllocationProps) {
  const chartData = holdings.map(holding => {
    const coin = getCoinById(holding.coinId);
    return {
      name: coin?.name || holding.coinId,
      value: holding.value,
      color: coin?.color || '#6B7280',
      percentage: (holding.value / totalPortfolioValue) * 100
    };
  });

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border border-gray-200">
          <p className="font-semibold text-gray-900">{data.name}</p>
          <p className="text-gray-700">{formatCurrency(data.value)}</p>
          <p className="text-gray-600">{data.percentage.toFixed(2)}% of portfolio</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Portfolio Allocation</h2>
        <div className="text-lg font-semibold text-gray-900">
          Total: {formatCurrency(totalPortfolioValue)}
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="lg:w-1/2">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:w-1/2">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Holdings Breakdown</h3>
            {holdings.map((holding) => {
              const coin = getCoinById(holding.coinId);
              const percentage = (holding.value / totalPortfolioValue) * 100;
              return (
                <div key={holding.coinId} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold"
                      style={{ backgroundColor: coin?.color || '#6B7280' }}
                    >
                      {coin?.icon || holding.coinId.charAt(0)}
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{coin?.name || holding.coinId}</div>
                      <div className="text-sm text-gray-500">{holding.amount.toFixed(4)} {coin?.symbol || ''}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-gray-900">{formatCurrency(holding.value)}</div>
                    <div className="text-sm text-gray-600">{percentage.toFixed(2)}%</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}