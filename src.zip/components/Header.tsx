import { TrendingUp, DollarSign, PieChartIcon, BarChart3 } from 'lucide-react';
import { formatCurrency, totalPortfolioValue, cryptoCoins } from '../data/cryptoData';
import RefreshButton from './RefreshButton';

interface HeaderProps {
  onRefresh?: () => void;
  totalPortfolioValue?: number;
}

export default function Header({ onRefresh, totalPortfolioValue: propTotalValue }: HeaderProps) {
  const totalChange24h = cryptoCoins.reduce((sum, coin) => sum + coin.change24h, 0) / cryptoCoins.length;
  const totalMarketCap = cryptoCoins.reduce((sum, coin) => sum + coin.marketCap, 0);
  const totalVolume24h = cryptoCoins.reduce((sum, coin) => sum + coin.volume24h, 0);
  
  // Use prop value or fallback to static value
  const displayTotalValue = propTotalValue !== undefined ? propTotalValue : totalPortfolioValue;

  return (
    <header className="mb-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-4xl font-bold text-gray-900">Crypto Portfolio Tracker</h1>
          <p className="text-gray-600 mt-2">Track your cryptocurrency investments in real-time</p>
        </div>
        <div className="flex items-center gap-4">
          <RefreshButton onRefresh={onRefresh} />
          <div className="flex items-center gap-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-2xl shadow-lg">
            <DollarSign className="w-6 h-6" />
            <div>
              <div className="text-sm opacity-90">Total Portfolio Value</div>
              <div className="text-2xl font-bold">{formatCurrency(displayTotalValue)}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-gray-500">Avg 24h Change</div>
              <div className={`text-2xl font-bold ${totalChange24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {totalChange24h >= 0 ? '+' : ''}{totalChange24h.toFixed(2)}%
              </div>
            </div>
            <TrendingUp className={`w-8 h-8 ${totalChange24h >= 0 ? 'text-green-500' : 'text-red-500'}`} />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-gray-500">Total Market Cap</div>
              <div className="text-2xl font-bold text-gray-900">
                ${(totalMarketCap / 1e12).toFixed(1)}T
              </div>
            </div>
            <BarChart3 className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-gray-500">24h Volume</div>
              <div className="text-2xl font-bold text-gray-900">
                ${(totalVolume24h / 1e9).toFixed(1)}B
              </div>
            </div>
            <PieChartIcon className="w-8 h-8 text-purple-500" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-gray-500">Assets in Portfolio</div>
              <div className="text-2xl font-bold text-gray-900">
                {cryptoCoins.length}
              </div>
            </div>
            <div className="flex -space-x-2">
              {cryptoCoins.slice(0, 4).map((coin) => (
                <div 
                  key={coin.id}
                  className="w-8 h-8 rounded-full border-2 border-white flex items-center justify-center text-xs font-bold text-white"
                  style={{ backgroundColor: coin.color }}
                >
                  {coin.symbol.charAt(0)}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}