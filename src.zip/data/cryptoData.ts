export interface CryptoCoin {
  id: string;
  name: string;
  symbol: string;
  currentPrice: number;
  marketCap: number;
  volume24h: number;
  change24h: number;
  sparklineData: number[];
  color: string;
  icon: string;
}

export interface PortfolioHolding {
  coinId: string;
  amount: number;
  value: number;
}

export const cryptoCoins: CryptoCoin[] = [
  {
    id: 'bitcoin',
    name: 'Bitcoin',
    symbol: 'BTC',
    currentPrice: 63125.42,
    marketCap: 1245678901234,
    volume24h: 45678901234,
    change24h: 2.34,
    sparklineData: [62000, 62500, 62250, 62800, 62750, 63000, 63125, 62900, 63050, 63125, 63200, 63125],
    color: '#F7931A',
    icon: '₿'
  },
  {
    id: 'ethereum',
    name: 'Ethereum',
    symbol: 'ETH',
    currentPrice: 3456.78,
    marketCap: 415678901234,
    volume24h: 15678901234,
    change24h: 1.56,
    sparklineData: [3400, 3420, 3410, 3440, 3430, 3450, 3456, 3445, 3452, 3456, 3460, 3456],
    color: '#627EEA',
    icon: 'Ξ'
  },
  {
    id: 'solana',
    name: 'Solana',
    symbol: 'SOL',
    currentPrice: 142.56,
    marketCap: 64567890123,
    volume24h: 2567890123,
    change24h: 5.23,
    sparklineData: [138, 139, 140, 141, 142, 142.5, 142.6, 142.2, 142.4, 142.6, 142.8, 142.6],
    color: '#00FFA3',
    icon: '◎'
  },
  {
    id: 'cardano',
    name: 'Cardano',
    symbol: 'ADA',
    currentPrice: 0.56,
    marketCap: 19876543210,
    volume24h: 987654321,
    change24h: -0.45,
    sparklineData: [0.57, 0.568, 0.565, 0.562, 0.56, 0.559, 0.558, 0.56, 0.561, 0.56, 0.559, 0.56],
    color: '#0033AD',
    icon: 'A'
  },
  {
    id: 'polkadot',
    name: 'Polkadot',
    symbol: 'DOT',
    currentPrice: 7.89,
    marketCap: 9876543210,
    volume24h: 456789012,
    change24h: 0.89,
    sparklineData: [7.8, 7.82, 7.85, 7.87, 7.88, 7.89, 7.9, 7.88, 7.89, 7.88, 7.89, 7.89],
    color: '#E6007A',
    icon: '●'
  },
  {
    id: 'chainlink',
    name: 'Chainlink',
    symbol: 'LINK',
    currentPrice: 18.34,
    marketCap: 9876543210,
    volume24h: 456789012,
    change24h: 3.12,
    sparklineData: [17.8, 17.9, 18.0, 18.1, 18.2, 18.3, 18.34, 18.3, 18.32, 18.33, 18.34, 18.34],
    color: '#2A5ADA',
    icon: '🔗'
  }
];

export const portfolioHoldings: PortfolioHolding[] = [
  { coinId: 'bitcoin', amount: 0.5, value: 31562.71 },
  { coinId: 'ethereum', amount: 3.2, value: 11061.70 },
  { coinId: 'solana', amount: 25, value: 3564.00 },
  { coinId: 'cardano', amount: 1000, value: 560.00 },
  { coinId: 'polkadot', amount: 150, value: 1183.50 },
  { coinId: 'chainlink', amount: 50, value: 917.00 }
];

export const totalPortfolioValue = portfolioHoldings.reduce((sum, holding) => sum + holding.value, 0);

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(value);
}

export function formatLargeNumber(value: number): string {
  if (value >= 1e12) {
    return `$${(value / 1e12).toFixed(2)}T`;
  }
  if (value >= 1e9) {
    return `$${(value / 1e9).toFixed(2)}B`;
  }
  if (value >= 1e6) {
    return `$${(value / 1e6).toFixed(2)}M`;
  }
  return `$${value.toFixed(2)}`;
}

export function getCoinById(id: string): CryptoCoin | undefined {
  return cryptoCoins.find(coin => coin.id === id);
}